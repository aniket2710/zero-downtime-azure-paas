﻿
namespace ZeroDowntime.Models
{
    using System;

    public class Item
    {
        public DateTime RequestTime { get; set; }
        public string Version { get; set; }
        public string Summary { get; set; }
    }
}